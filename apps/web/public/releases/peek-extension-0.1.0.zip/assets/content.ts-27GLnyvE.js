(function(){function R(e){return e.startsWith("xpath=")?{type:"xpath",value:e.slice(6)}:e.startsWith("text=")?{type:"text",value:e.slice(5)}:{type:"css",value:e}}function z(e,t){return e==="xpath"?`xpath=${t}`:e==="text"?`text=${t}`:t}function M(e){if(e.id){const t=`#${CSS.escape(e.id)}`;if(document.querySelectorAll(t).length===1)return t}if(e.classList.length>0){const t=Array.from(e.classList).map(r=>`.${CSS.escape(r)}`).join(""),n=`${e.tagName.toLowerCase()}${t}`;if(document.querySelectorAll(n).length===1)return n;if(document.querySelectorAll(t).length===1)return t}return H(e)}function H(e){const t=[];let n=e;for(;n&&n!==document.documentElement;){const r=n.parentElement;if(!r)break;const c=n.tagName.toLowerCase(),a=n.tagName,p=Array.from(r.children).filter(f=>f.tagName===a),_=p.indexOf(n)+1;t.unshift(p.length===1?c:`${c}:nth-child(${_})`),n=r}return t.join(" > ")}function B(e){const t=[];let n=e;for(;n&&n.nodeType===Node.ELEMENT_NODE;){const r=n.parentElement,c=n.tagName.toLowerCase(),a=n.tagName;if(r){const p=Array.from(r.children).filter(f=>f.tagName===a),_=p.indexOf(n)+1;t.unshift(p.length===1?c:`${c}[${_}]`)}else t.unshift(c);n=r}return"/"+t.join("/")}let s=null,x="css",u="",l=null,m=null,g=null,i=null,d=null;const o={canvas:"#F8FAFC",surface:"#FFFFFF",ghost:"#F1F5F9",line:"rgba(15,23,42,0.12)",ink:"#0F172A",inkSoft:"#1E293B",inkMuted:"#475569",accent:"#22C55E"},I=[/^localhost$/i,/^127\./,/^10\./,/^172\.(1[6-9]|2[0-9]|3[01])\./,/^192\.168\./,/^169\.254\./,/^::1$/,/\.local$/i];function O(e){return I.some(t=>t.test(e))}function j(){if(document.getElementById("__peek_host__"))return;if(O(window.location.hostname)){D();return}l=document.createElement("div"),l.id="__peek_host__",l.style.cssText="all: initial; position: fixed; inset: 0; pointer-events: none; z-index: 2147483647;",document.body.appendChild(l),m=l.attachShadow({mode:"open"}),g=document.createElement("div"),g.style.cssText=`
    position: fixed; pointer-events: none; z-index: 2147483646;
    outline: 2px solid ${o.accent}; outline-offset: 1px;
    background: rgba(34,197,94,0.08); border-radius: 3px;
    transition: top 0.05s, left 0.05s, width 0.05s, height 0.05s;
  `,m.appendChild(g);const e=document.createElement("div");e.style.cssText=`
    position: fixed; top: 0; left: 0; right: 0; pointer-events: auto;
    background: ${o.ink}; color: ${o.surface}; font: 600 12px/1.4 'Inter', -apple-system, system-ui, sans-serif;
    padding: 8px 12px; display: flex; align-items: center; gap: 10px; z-index: 2147483647;
    box-shadow: 0 8px 24px rgba(0,0,0,0.18);
  `,e.innerHTML='<span style="letter-spacing:0.02em">Peek — click any element to select it</span><span style="margin-left:auto;opacity:.75;font-size:11px">Esc to cancel</span>',m.appendChild(e),document.addEventListener("mousemove",A,!0),document.addEventListener("click",q,!0),document.addEventListener("keydown",C,!0),document.addEventListener("contextmenu",k,!0),document.addEventListener("scroll",v,!0),window.addEventListener("resize",v)}function D(){l=document.createElement("div"),l.id="__peek_host__",l.style.cssText="all: initial; position: fixed; inset: 0; pointer-events: none; z-index: 2147483647;",document.body.appendChild(l),m=l.attachShadow({mode:"open"});const e=document.createElement("div");e.style.cssText=`
    position: fixed; top: 0; left: 0; right: 0; pointer-events: auto;
    background: #7f1d1d; color: ${o.surface}; font: 600 12px/1.4 'Inter', -apple-system, system-ui, sans-serif;
    padding: 8px 12px; display: flex; align-items: center; gap: 10px; z-index: 2147483647;
  `,e.innerHTML=`
    <span>Peek can't track pages on private networks (${S(window.location.hostname)})</span>
    <button id="__peek_close__" style="margin-left:auto;background:none;border:none;color:#fff;cursor:pointer;font-size:16px;line-height:1;opacity:.8">×</button>
  `,m.appendChild(e),document.addEventListener("keydown",C,!0),e.querySelector("#__peek_close__").addEventListener("click",b)}function b(){document.removeEventListener("mousemove",A,!0),document.removeEventListener("click",q,!0),document.removeEventListener("keydown",C,!0),document.removeEventListener("contextmenu",k,!0),document.removeEventListener("scroll",v,!0),window.removeEventListener("resize",v),l==null||l.remove(),l=null,m=null,g=null,i=null,d=null,s=null}function A(e){if(s)return;const t=document.elementFromPoint(e.clientX,e.clientY);!t||t===l||w(t)}function q(e){if(e.target===l||(k(e),s))return;const t=document.elementFromPoint(e.clientX,e.clientY);!t||t===l||U(t)}function C(e){e.key==="Escape"&&(k(e),b())}function k(e){e.target!==l&&(e.stopPropagation(),e.preventDefault())}function v(){s&&w(s),d&&s&&L(s)}function w(e){if(!g)return;const t=e.getBoundingClientRect();g.style.cssText+=`
    top: ${t.top}px; left: ${t.left}px;
    width: ${t.width}px; height: ${t.height}px;
    display: block;
  `}function U(e){s=e,x="css",u=M(e),g&&(g.style.outline=`2px solid ${o.accent}`,g.style.background="rgba(34,197,94,0.10)"),X(e),W()}function X(e){if(!m)return;d==null||d.remove();const t=e.tagName.toLowerCase(),n=e.id?`#${e.id}`:e.classList[0]?`.${e.classList[0]}`:"";d=document.createElement("div"),d.style.cssText=`
    position: fixed; pointer-events: auto; z-index: 2147483647;
    background: ${o.ink}; color: ${o.surface}; border-radius: 8px;
    font: 12px/1.2 'Inter', -apple-system, system-ui, sans-serif;
    display: flex; align-items: center; gap: 4px; padding: 6px 9px;
    box-shadow: 0 10px 30px rgba(0,0,0,.35);
    border: 1px solid ${o.line};
  `,d.innerHTML=`
    <button id="__peek_up__" style="background:${o.surface};border:1px solid ${o.line};color:${o.ink};cursor:pointer;padding:2px 6px;border-radius:6px;font-size:12px;font-weight:600;box-shadow:0 2px 6px rgba(0,0,0,.08)">↑</button>
    <span style="opacity:.75;font-size:11px;color:${o.surface}">${t}${n}</span>
    <button id="__peek_down__" style="background:${o.surface};border:1px solid ${o.line};color:${o.ink};cursor:pointer;padding:2px 6px;border-radius:6px;font-size:12px;font-weight:600;box-shadow:0 2px 6px rgba(0,0,0,.08)">↓</button>
  `,m.appendChild(d),L(e),d.querySelector("#__peek_up__").addEventListener("click",()=>{s!=null&&s.parentElement&&s.parentElement!==document.documentElement&&(s=s.parentElement,P(s))}),d.querySelector("#__peek_down__").addEventListener("click",()=>{s!=null&&s.firstElementChild&&(s=s.firstElementChild,P(s))})}function L(e){if(!d)return;const t=e.getBoundingClientRect(),n=Math.max(t.bottom+6,36);d.style.top=`${n}px`,d.style.left=`${t.left}px`}function P(e){w(e),L(e),u=N(e,x),F(),E();const t=e.tagName.toLowerCase(),n=e.id?`#${e.id}`:e.classList[0]?`.${e.classList[0]}`:"",r=d==null?void 0:d.querySelector("span");r&&(r.textContent=`${t}${n}`)}function N(e,t){var n;return t==="css"?M(e):t==="xpath"?z("xpath",B(e)):z("text",((n=e.textContent)==null?void 0:n.trim().slice(0,100))??"")}function $(e){const{type:t,value:n}=R(e);try{if(t==="css")return Array.from(document.querySelectorAll(n));if(t==="xpath"){const r=document.evaluate(n,document,null,XPathResult.ORDERED_NODE_SNAPSHOT_TYPE,null),c=[];for(let a=0;a<r.snapshotLength;a++){const p=r.snapshotItem(a);p instanceof Element&&c.push(p)}return c}if(t==="text")return Array.from(document.querySelectorAll("*")).filter(r=>{var c;return(c=r.textContent)==null?void 0:c.trim().includes(n)})}catch{}return[]}function W(){var c;if(!m)return;i==null||i.remove();const e=((c=s==null?void 0:s.textContent)==null?void 0:c.trim())??"";i=document.createElement("div"),i.style.cssText=`
    position: fixed; top: 0; right: 0; bottom: 0; width: 320px;
    background: ${o.surface}; border-left: 1px solid ${o.line};
    font: 13px/1.6 'Inter', -apple-system, system-ui, sans-serif; color: ${o.ink};
    display: flex; flex-direction: column; z-index: 2147483647;
    pointer-events: auto; overflow: hidden;
    box-shadow: -6px 0 28px rgba(15,23,42,0.14);
  `;const t=chrome.runtime.getURL("icons/icon48.png");i.innerHTML=`
    <div style="padding:14px 14px 12px;border-bottom:1px solid ${o.line};display:flex;align-items:center;gap:10px;background:${o.surface};position:sticky;top:0;z-index:1">
      <img src="${t}" alt="Peek logo" style="width:20px;height:20px" />
      <div style="display:flex;flex-direction:column;gap:1px;align-items:flex-start">
        <strong style="font-size:14px;letter-spacing:-0.01em">Peek</strong>
      </div>
      <button id="__peek_cancel__" style="margin-left:auto;background:none;border:none;cursor:pointer;color:${o.inkMuted};font-size:18px;line-height:1;padding:4px;transition:color .15s" aria-label="Close">×</button>
    </div>
    <div style="flex:1;overflow-y:auto;padding:14px;display:flex;flex-direction:column;gap:14px;background:${o.canvas}">
      <div>
        <label style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.05em;color:${o.inkMuted};display:block;margin-bottom:6px">Selector type</label>
        <div id="__peek_mode__" style="display:flex;gap:6px">
          ${["css","xpath","text"].map(a=>`
            <button data-mode="${a}" style="
              flex:1;padding:7px 8px;border-radius:8px;font-size:12px;cursor:pointer;
              border:1px solid ${a===x?o.accent:o.line};
              background:${a===x?o.accent:o.surface};
              color:${a===x?"#0B1220":o.inkSoft};
              font-weight:${a===x?"700":"500"};
              box-shadow:${a===x?"0 6px 16px rgba(34,197,94,0.25)":"none"};
              transition: border-color .15s, box-shadow .15s;
            ">${a.toUpperCase()}</button>
          `).join("")}
        </div>
      </div>
      <div>
        <label style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.05em;color:${o.inkMuted};display:block;margin-bottom:6px">Selector</label>
        <textarea id="__peek_selector__" rows="3" style="
          width:100%;padding:9px 11px;border:1px solid ${o.line};border-radius:8px;
          font:12px/1.6 'Menlo','Monaco',monospace;resize:vertical;
          box-sizing:border-box;outline:none;background:${o.surface};color:${o.inkSoft};
          box-shadow: inset 0 1px 2px rgba(15,23,42,0.04);
        "></textarea>
        <p id="__peek_sel_status__" style="font-size:11px;color:${o.inkMuted};margin-top:6px"></p>
      </div>
      <div>
        <label style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.05em;color:${o.inkMuted};display:block;margin-bottom:6px">Content preview</label>
        <div id="__peek_preview__" style="
          font-size:12px;line-height:1.6;color:${o.inkSoft};
          background:${o.ghost};border:1px solid ${o.line};border-radius:8px;
          padding:10px 12px;max-height:140px;overflow-y:auto;
          white-space:pre-wrap;word-break:break-word;
        ">${S(e.slice(0,500))}</div>
      </div>
      <div>
        <label style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.05em;color:${o.inkMuted};display:block;margin-bottom:6px">URL</label>
        <p style="font-size:12px;color:${o.inkSoft};word-break:break-all">${S(window.location.href)}</p>
      </div>
    </div>
    <div style="padding:12px 14px;border-top:1px solid ${o.line};display:flex;gap:8px;background:${o.surface}">
      <button id="__peek_save__" style="
        flex:1;padding:11px;background:${o.accent};color:#0B1220;border:none;
        border-radius:9px;font-size:13px;font-weight:700;cursor:pointer;
        box-shadow:0 10px 30px rgba(34,197,94,0.35);
      ">Save to Peek</button>
    </div>
    <div id="__peek_toast__" style="
      position:absolute;bottom:60px;left:14px;right:14px;
      padding:10px 12px;border-radius:8px;font-size:12px;
      display:none;text-align:center;font-weight:600;
    "></div>
  `,m.appendChild(i);const n=i.querySelector("#__peek_selector__");n&&(n.value=u),i.querySelector("#__peek_mode__").addEventListener("click",a=>{const p=a.target.closest("[data-mode]");!p||!s||(x=p.dataset.mode,u=N(s,x),i.querySelectorAll("[data-mode]").forEach(_=>{const f=_,h=f.dataset.mode===x;f.style.border=`1px solid ${h?o.accent:o.line}`,f.style.background=h?o.accent:o.surface,f.style.color=h?"#0B1220":o.inkSoft,f.style.fontWeight=h?"700":"500",f.style.boxShadow=h?"0 6px 16px rgba(34,197,94,0.25)":"none"}),F(),E())});let r;i.querySelector("#__peek_selector__").addEventListener("input",a=>{clearTimeout(r),r=setTimeout(()=>{u=a.target.value.trim(),Y()},300)}),i.querySelector("#__peek_cancel__").addEventListener("click",b),i.querySelector("#__peek_save__").addEventListener("click",K),T($(u).length)}function F(){const e=i==null?void 0:i.querySelector("#__peek_selector__");e&&(e.value=u),T($(u).length)}function E(){var r,c;const t=((c=(r=$(u)[0])==null?void 0:r.textContent)==null?void 0:c.trim().slice(0,500))??"",n=i==null?void 0:i.querySelector("#__peek_preview__");n&&(n.textContent=t)}function T(e){const t=i==null?void 0:i.querySelector("#__peek_sel_status__");t&&(e===0?(t.textContent="No elements match",t.style.color="#ef4444"):e===1?(t.textContent="Matches 1 element ✓",t.style.color="#10b981"):(t.textContent=`Matches ${e} elements`,t.style.color="#f59e0b"))}function Y(){const e=$(u);T(e.length),e[0]&&w(e[0]),E()}async function K(){const e=i==null?void 0:i.querySelector("#__peek_save__");if(!e)return;e.disabled=!0,e.textContent="Saving…";const t=await chrome.runtime.sendMessage({type:"GET_AUTH"});if(!t.accessToken){y("Session expired — please sign in again","error"),await chrome.runtime.sendMessage({type:"CLEAR_AUTH"}),e.disabled=!1,e.textContent="Save to Peek";return}try{const n=await fetch("https://peek.bushbaby.dev/api/items",{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${t.accessToken}`},body:JSON.stringify({url:window.location.href,selector:u})});if(n.status===401){await chrome.runtime.sendMessage({type:"CLEAR_AUTH"}),y("Session expired — please sign in again","error"),e.disabled=!1,e.textContent="Save to Peek";return}if(!n.ok){const r=await n.json();y(r.error??"Something went wrong","error"),e.disabled=!1,e.textContent="Save to Peek";return}y("Added to Peek ✓","success"),setTimeout(b,1500)}catch{y("Network error — please try again","error"),e.disabled=!1,e.textContent="Save to Peek"}}function y(e,t){const n=i==null?void 0:i.querySelector("#__peek_toast__");n&&(n.textContent=e,n.style.display="block",n.style.background=t==="success"?"#d1fae5":"#fee2e2",n.style.color=t==="success"?"#065f46":"#991b1b",t!=="success"&&setTimeout(()=>{n.style.display="none"},3e3))}function S(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}chrome.runtime.onMessage.addListener(e=>{e.type==="START_PICKER"&&(b(),j())});chrome.storage.onChanged.addListener((e,t)=>{var r;if(t!=="local"||!((r=e.accessToken)!=null&&r.newValue))return;const n=i==null?void 0:i.querySelector("#__peek_toast__");n&&(n.style.display="none")});
})()
