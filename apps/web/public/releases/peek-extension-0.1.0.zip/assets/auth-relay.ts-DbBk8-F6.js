(function(){window.addEventListener("message",a=>{a.origin==="https://peek.bushbaby.dev"&&a.data&&typeof a.data=="object"&&a.data.type==="PEEK_TOKEN"&&typeof a.data.accessToken=="string"&&typeof a.data.refreshToken=="string"&&chrome.runtime.sendMessage({type:"STORE_TOKEN",accessToken:a.data.accessToken,refreshToken:a.data.refreshToken})});
})()
